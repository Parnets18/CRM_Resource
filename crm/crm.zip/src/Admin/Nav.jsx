import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  Banknote, MapPin, Scale, ShoppingCart, Warehouse, Users,
  ChevronDown, ChevronRight, UserPlus, FileSpreadsheet, Calendar,
  Building, Settings, Users2, ClipboardList, Package, BarChart3,
  CreditCard, Receipt, DollarSign, PieChart, Wallet, Calculator,
  Menu, X
} from "lucide-react";
import { Link } from "react-router-dom";

function useIsMobile() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  return isMobile;
}


export default function Nav() {
  const [expandedSection, setExpandedSection] = useState(null);
  const [isNavOpen, setIsNavOpen] = useState(false);
  const isMobile = useIsMobile();

  const navItems = [
    {
      title: "HR & Payroll Module",
      icon: MapPin,
      id: "hr",
      subtabs: [
        { title: "Admin", icon: UserPlus ,  path: "/adminPayroll"},
        { title: "HR Manager", icon: FileSpreadsheet, path:"/manager" },
        { title: "Employee", icon: Calendar, path:"/employee" }
      ]
    },
    {
      title: "Site Management",
      icon: Users,
      id: "site",
      subtabs: [
        { title: "Admin", icon: Building, path:"/siteadmin" },
        { title: "Project Manager", icon: Settings ,path:"/siteproject"},
        { title: "Site Supervisor", icon: Users2 ,path:'/sitesupervisor'}
      ]
    },
    {
      title: "Indent & Inventory",
      icon: Warehouse,
      id: "inventory",
      subtabs: [
        { title: "Site Supervisor", icon: ClipboardList,path:"/inventorysite"},
        { title: "Procurement Office", icon: Package ,path:"/inventoryofficer"},
        
        { title: "Project Manager", icon: Users ,path:"/inventorymanager"},
        { title: "Admin", icon: BarChart3 , path:"/inventoryadmin"}
      ]
    },
    {
      title: "Purchase Management",
      icon: ShoppingCart,
      id: "purchase",
      subtabs: [
        { title: "Procurement Officer", icon: CreditCard, path: "/purchaseofficer" },
        { title: "Accountant", icon: Users , path:"/purchaseaccountant"},
        { title: "Admin", icon: Receipt ,path:'/purchaseadmin'},
        
      ]
    },
    {
      title: "Sales Management",
      icon: Banknote,
      id: "sales",
      subtabs: [
        { title: "Admin", icon: DollarSign ,path:'/salesadmin' },
        { title: "Accountant", icon: PieChart, path:'/salesaccountant' },
        { title: "Project Manager", icon: Users ,path:'/salesproject'}
      ]
    },
    {
      title: "Expense Management",
      icon: Scale,
      id: "expense",
      subtabs: [
        { title: "Site Supervisor", icon: Wallet ,path:'/expensesupervisor'},
        { title: "Project Manager", icon: Calculator ,path:'/expensemanager'},
        { title: "Accountant", icon: BarChart3 ,path:'/expenseaccountant'},
        { title: "Admin", icon: DollarSign ,path:'/expenseadmin'},
      ]
    }
  ];

  return (
    <>
      {/* Hamburger Menu Button */}
      {isMobile && !isNavOpen && (
      <button
        onClick={() => setIsNavOpen(true)}
        className="md:hidden fixed top-4 left-4 z-50 p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white"
      >
        <Menu className="w-6 h-6" />
      </button>
    )}

    <motion.div 
      initial={{ x: isMobile ? '-100%' : 0 }}
      animate={{ x: (isMobile && !isNavOpen) ? '-100%' : 0 }}
      transition={{ type: 'tween', duration: 0.3 }}
      className="w-64 fixed top-0 left-0 h-screen border-r border-purple-500/20 bg-black backdrop-blur-sm p-4 overflow-y-auto z-40"
    >
        <div className="flex items-center gap-2 mb-8">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
            className="h-8 w-8 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center"
          >
            <span className="text-white font-bold text-sm">N</span>
          </motion.div>
          <h1 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
            NexusCRM
          </h1>
          {isMobile && (
            <button onClick={() => setIsNavOpen(false)} className="ml-auto">
              <X className="w-6 h-6 text-purple-400" />
            </button>
          )}
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => (
            <div key={item.id}>
              <Button
                variant="ghost"
                className="w-full justify-start text-gray-300 hover:bg-gray-900/50 hover:text-white"
                onClick={() => setExpandedSection(expandedSection === item.id ? null : item.id)}
              >
                <item.icon className="w-4 h-4 mr-2 text-purple-400" />
                <span className="flex-1">{item.title}</span>
                {expandedSection === item.id ? (
                  <ChevronDown className="w-4 h-4 text-purple-400" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-purple-400" />
                )}
              </Button>
              <AnimatePresence>
                {expandedSection === item.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    {item.subtabs.map((subtab, index) => (
                      <Link 
                        key={index}
                        to={subtab.path}
                        className="block no-underline"
                        onClick={() => isMobile && setIsNavOpen(false)}
                      >
                        <Button
                          variant="ghost"
                          className="w-full justify-start text-gray-400 hover:bg-gray-900/50 hover:text-white pl-8"
                        >
                          <subtab.icon className="w-4 h-4 mr-2 text-purple-400" />
                          {subtab.title}
                        </Button>
                      </Link>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </nav>
      </motion.div>
    </>
  );
}